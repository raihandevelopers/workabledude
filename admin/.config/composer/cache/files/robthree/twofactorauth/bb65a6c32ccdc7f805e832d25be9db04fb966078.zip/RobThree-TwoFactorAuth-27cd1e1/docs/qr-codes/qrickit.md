---
layout: post
title: QRickit
---

## Optional Configuration

Argument                | Default value
------------------------|---------------
`$errorcorrectionlevel` | `'L'`
`$bgcolor`              | `'ffffff'`
`$color`                | `'000000'`
`$format`               | `'png'`

The parameters are passed to [QRickit](http://qrickit.com/qrickit_apps/qrickit_api.php) so you can refer to them for more detail on how the values are used.
