<?php

declare(strict_types=1);

namespace RobThree\Auth;

use Exception;

class TwoFactorAuthException extends Exception
{
}
